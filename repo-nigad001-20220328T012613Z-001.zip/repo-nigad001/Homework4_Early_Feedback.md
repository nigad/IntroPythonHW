### Early Feedback for Homework 4 (THIS IS NOT YOUR GRADE, the assignment isn't due yet)

These tests are run on Tuesday nights around 11:55 PM, so if you didn't submit before then you can ignore this document

Passing these tests is not a guarantee of a perfect homework score: the tests do not check everything that the TAs will.

Any questions/errors with the Automated Feedback should be reported to Nathan Taylor: taylo740@umn.edu

Run on October 02, 00:12:06 AM.

+ Pass: Change into directory "hw4".

+ Pass: Check that file "hw4.py" exists.

+ Pass: Check that Python file "hw4.py" only imports permitted modules.

+ Pass: Check that a Python file "hw4.py" has no syntax errors.

    Python file "hw4.py" has no syntax errors.



+ Pass: Writing encrypted5.txt into local directory  
File Contents:
```
402153397
iojzkpgqzcv{c{z{kicgmnd|teggoah|xe

```




+ Fail: 
Check that the result of evaluating
   ```
   find_password('encrypted5.txt') + 'o'
   ```
   matches the pattern `'mario'`.

   


   Test failed. The following errors were reported:

```
 
Traceback (most recent call last):
  File "<stdin>", line 1, in <module>
TypeError: unsupported operand type(s) for +: 'NoneType' and 'str'

```


+ Fail: 
Check that the result of evaluating
   ```
   count_primes(128374612, 128374711) + count_primes(1, 2)
   ```
   matches the pattern `9`.

   


   Your solution evaluated incorrectly and produced:

 
```
 
128374657 is prime
128374663 is prime
128374669 is prime
128374679 is prime
128374691 is prime
128374693 is prime
128374699 is prime
128374711 is prime
1 is prime
2 is prime
10

```



+ Pass: 
Check that the result of evaluating
   ```
   population(900, 600, 300) + population(300, 600, 900)
   ```
   matches the pattern `165`.

   




