Grade: 40/40  
Comments: Looks great, nice work!