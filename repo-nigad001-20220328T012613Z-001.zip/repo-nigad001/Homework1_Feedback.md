### Early Feedback for Homework 1 (THIS IS NOT YOUR GRADE)

Run on September 15, 17:42:31 PM.

+ Pass: Change into directory "hw1".

+ Pass: Check that file "hw1.py" exists.

+ Pass: Check that a Python file "hw1.py" has no syntax errors.

    Python file "hw1.py" has no syntax errors.



+ Pass: 
Check that the result of evaluating
   ```
   cents(1,1,0,3)
   ```
   matches the pattern `38`.

   




+ Pass: 
Check that the result of evaluating
   ```
   cents(2,0,3,5)
   ```
   matches the pattern `70`.

   




