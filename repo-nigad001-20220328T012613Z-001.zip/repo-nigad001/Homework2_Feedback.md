### Early Feedback for Homework 2 (THIS IS NOT YOUR GRADE, the assignment isn't due yet)

Passing these tests is not a guarantee of a perfect homework score: the tests do not check everything that the TAs will.

Any questions/errors with the Automated Feedback should be reported to Nathan Taylor: taylo740@umn.edu

Run on September 18, 00:22:00 AM.

+ Pass: Change into directory "hw2".

+ Pass: Check that file "hw2.py" exists.

+ Pass: Check that Python file "hw2.py" only imports permitted modules.

+ Pass: Check that a Python file "hw2.py" has no syntax errors.

    Python file "hw2.py" has no syntax errors.



+ Pass: 
Check that the result of evaluating
   ```
   length_contract(1000, 298765432)
   ```
   is approximately `90.62846265282911`.

   




+ Pass: 
Check that the result of evaluating
   ```
   bessel_run(295000000)
   ```
   is approximately `7.232249748056239`.

   




+ Pass: 
Check that the result of evaluating
   ```
   print_100()
   ```
   is 'Who needs loops?' printed 100 times.

   




